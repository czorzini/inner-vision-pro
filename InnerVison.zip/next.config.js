/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["earth.fm"]
    }
}

module.exports = nextConfig
